package com.jsp.springboot.actor.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.springboot.actor.exception.ActorNotFoundByIdException;
import com.jsp.springboot.actor.model.Actor;
import com.jsp.springboot.actor.repository.ActorRepository;
import com.jsp.springboot.actor.service.ActorService;
import com.jsp.springboot.actor.utility.ResponseStructure;

@Service
public class ActorServiceImpl implements ActorService{
	
	@Autowired
	private ActorRepository repo;

	@Override
	public String addActor(Actor actor) {
		repo.save(actor);
		return "Data Saved Successfully..!!!";
	}

	@Override
	public ResponseEntity<ResponseStructure<Actor>> addActorDetails(Actor actor) {
		actor = repo.save(actor);
		
		ResponseStructure<Actor> responseStructure = new ResponseStructure<>();
		responseStructure.setData(actor);
		responseStructure.setMessage("Actor Created Successfull");
		responseStructure.setStatuscode(HttpStatus.CREATED.value());
		
		return new ResponseEntity<ResponseStructure<Actor>>(responseStructure, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<ResponseStructure<Actor>> findByActorId(int actorId) {
		Optional<Actor> option = repo.findById(actorId);
		if(option.isPresent()) {
			Actor actor = option.get();
			
			ResponseStructure<Actor> responseStructure = new ResponseStructure<>();
			responseStructure.setData(actor);
			responseStructure.setMessage("Actor Details Found for given Id.");
			responseStructure.setStatuscode(HttpStatus.FOUND.value());
			
			return new ResponseEntity<ResponseStructure<Actor>>(responseStructure, HttpStatus.FOUND);
		}
		else {
			throw new ActorNotFoundByIdException("Actor Not Found");
		}
	}

	@Override
	public ResponseEntity<ResponseStructure<Actor>> updateByActorId(int actorId, Actor updatedActor) {
		Optional<Actor> actor = repo.findById(actorId);
		
		if(actor.isPresent()) {
			Actor existActor = actor.get();
			updatedActor.setActorId(existActor.getActorId());
			
			ResponseStructure<Actor> responseStructure = new ResponseStructure<>();
			responseStructure.setData(updatedActor);
			responseStructure.setMessage("Actor Updated Successfully");
			responseStructure.setStatuscode(HttpStatus.OK.value());
			
			return new ResponseEntity<ResponseStructure<Actor>>(responseStructure, HttpStatus.OK);
		} else {
			return null;
		}	
	}

	@Override
	public ResponseEntity<ResponseStructure<Actor>> deleteByActorId(int actorId) {
		Optional<Actor> actor = repo.findById(actorId);
		
		if(actor.isPresent()) {
			Actor existActor = actor.get();
			repo.delete(existActor);
			ResponseStructure<Actor> responseStructure = new ResponseStructure<>();
			responseStructure.setData(existActor);
			responseStructure.setMessage("Actor Details Found for given Id.");
			responseStructure.setStatuscode(HttpStatus.OK.value());
			
			return new ResponseEntity<ResponseStructure<Actor>>(responseStructure, HttpStatus.OK);
		}
		else {
			return null;
		}
	}

	@Override
	public ResponseEntity<ResponseStructure<List<Actor>>> findAllActors() {
		List<Actor> actors = repo.findAll();
		
		if(actors.isEmpty()) {
			return null;
		} else {
			ResponseStructure<List<Actor>> responseStructure = new ResponseStructure<>();
			responseStructure.setData(actors);
			responseStructure.setMessage("Actors Details Found.");
			responseStructure.setStatuscode(HttpStatus.FOUND.value());
			
			return new ResponseEntity<ResponseStructure<List<Actor>>>(responseStructure, HttpStatus.FOUND);
		}
	}
	
	

}
