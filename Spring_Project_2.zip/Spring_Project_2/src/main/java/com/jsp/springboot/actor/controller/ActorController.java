package com.jsp.springboot.actor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.springboot.actor.model.Actor;
import com.jsp.springboot.actor.service.ActorService;
import com.jsp.springboot.actor.utility.ResponseStructure;

//@Controller
//@ResponseBody
@RestController
public class ActorController {
	
	@Autowired
	private ActorService service;
	
//	This method is to display the String after successfully saving the data.
//	@RequestMapping(method = RequestMethod.POST, value="/actors/addActor")
	@PostMapping("/actors/addActor")
	public String addActor(@RequestBody Actor actor) {
		return service.addActor(actor);
	}
	
//	This method is to display the object which is saved successfully.
//	@RequestMapping(method = RequestMethod.POST, value="/actors/addActorDetails")
	@PostMapping("/actors/addActorDetails")
	public ResponseEntity<ResponseStructure<Actor>> addActorDetails(@RequestBody Actor actor) {
		return service.addActorDetails(actor);
	}
	
//	Rather then @RequestParam we are using the @PathVariable to recevie paramaeters from url
//	@RequestMapping(method = RequestMethod.GET, value="/print")
	@GetMapping("/print/{name}/{city}")
	public String printString(@PathVariable String name, @PathVariable String city) {
		return name + " " + city;
	}
	
//	@RequestMapping(method = RequestMethod.GET, value = "/actors/findByActorId")
	@GetMapping("/actors/findByActorId/{actorId}")
	public ResponseEntity<ResponseStructure<Actor>> findByActorId(@PathVariable int actorId) {
		return service.findByActorId(actorId);
	}
	
//	@RequestMapping(method = RequestMethod.PUT, value = "/actors/updateByActorId")
	@PutMapping("/actors/updateByActorId/{actorId}")
	public ResponseEntity<ResponseStructure<Actor>> updateByActorId(@PathVariable int actorId, @RequestBody Actor updateActor) {
		return service.updateByActorId(actorId, updateActor);
	}
	
//	@RequestMapping(method = RequestMethod.DELETE, value = "/actors/deleteByActorId")
	@DeleteMapping("/actors/deleteByActorId/{actorId}")
	public ResponseEntity<ResponseStructure<Actor>> deleteByActorId(@PathVariable int actorId) {
		return service.deleteByActorId(actorId);
	}
	
//	@RequestMapping(method = RequestMethod.GET, value = "/actors/findAllActors")
	@GetMapping("/actors/findAllActors")
	public ResponseEntity<ResponseStructure<List<Actor>>> findAllActors() {
		return service.findAllActors();
	}
	

}
